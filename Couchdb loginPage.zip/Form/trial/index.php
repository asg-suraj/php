
<!DOCTYPE html>  
<head>




<link href="css/EnterData.css" rel="stylesheet" type="text/css"/>



<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 

<style>
body
{
	margin:auto;
	border:thick;
	background-color:#8DEDBF;
}
			

</style>
<link href="css/EnterData.css" rel="stylesheet" type="text/css">

</head>

<body>
<ul>

	<form action="" method="GET" >  


	<p><strong><em>Id:</em></strong></p>
	
	<p>
		<input name="id" type="text"  id="id" placeholder="Enter Your Id"   background-color="red">
	</p>
	
	<p><strong><em>Name<em></strong></p>

	<p>
		<input name="name" type="text"  id="name" placeholder="Enter Name" >
	</p>
	<p><strong><em>lastname<em></strong></p>

	<p>
		<input name="lastname" type="text"  id="lastname" placeholder="Enter lastname" >
	</p>
	<p>
		<input name="submit" type="submit" autofocus value="submit"/>
	</p>
</form>
</ul>

</body>
</html>








<?php  

$options['host'] = "localhost";   
$options['port'] = 5984;  
// Creating connection  
$couch = new CouchSimple($options);   
$couch->send("GET", "/");   
// Create a new database "javatpoint".  
$couch->send("PUT", "/test7");  
$couch->send("PUT", "/javayy"); 
$couch->send("PUT", "/javatpoint");
$resp="";
$resp1="";
$resp2="";
if(isset($_GET['submit'])){ 
$s=$_GET[name];
$q=$_GET[lastname];
// Create a new document in the database'.  ''''''''
$resp=$couch->send("PUT", "/test7/$_GET[id]", '{ "_id":"$_GET[id]"}' ); 
$resp1=$couch->send("PUT", "/javayy/$s", '{ "$s":"$s"}' ); 
$resp2=$couch->send("PUT", "/javatpoint/$q", '{ "$q":"$q"}' );
var_dump($resp);
}
//var_dump($resp1);
//$couch->send("PUT", "/javatpoint/45", '{"_id":"700",name":"its me"}');   
// Fetching document  
//$resp = $couch->send("GET", "/javatpoint/45");   
//$resp11 = $couch->send("GET", "/test7/$_GET[id]"); 
//echo $resp;
echo $resp;
echo $resp1;
echo $resp2;   

class CouchSimple {  
function CouchSimple($options) {  
foreach($options AS $key => $value) {  
$this->$key = $value;  
}  
}   
function send($method, $url, $post_data = NULL) {  
$s = fsockopen($this->host, $this->port, $errno, $errstr);   
if(!$s) {  
echo "$errno: $errstr\n";   
return false;  
}   
$request = "$method $url HTTP/1.0\r\nHost: $this->host\r\n";   
//if ($this->user) {  
//$request .= "Authorization: Basic ".base64_encode("$this->user:$this->pass")."\r\n";   
//}  
if($post_data) {  
$request .= "Content-Length: ".strlen($post_data)."\r\n\r\n";   
$request .= "$post_data\r\n";  
}   
else {  
$request .= "\r\n";  
}  
fwrite($s, $request);   
$response = "";   
while(!feof($s)) {  
$response .= fgets($s);  
}  
list($this->headers, $this->body) = explode("\r\n\r\n", $response);   
return $this->body;  
}  
}  
echo '<link href="w3.css" rel="stylesheet">';
	echo '<div class="w3-panel w3-green">';
			 echo '<h3>Success!</h3>';
			 echo '<p>New record created successfully.</p>';
			 //echo '<button class="w3-button w3-black"><a href=home.php>Home</a></button>';
			echo '</div>';


			?>  
